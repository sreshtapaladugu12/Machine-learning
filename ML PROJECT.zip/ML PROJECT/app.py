"""
Forest Fire Risk Prediction Web Application
Backend: Python Flask
Models: RandomForestClassifier & GradientBoostingClassifier
Syllabus Mapping: M1-M6
"""

import os
import json
import joblib
import numpy as np
import pandas as pd
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify

app = Flask(__name__)
app.secret_key = 'forest_fire_risk_prediction_secret_key_2026'

# Path constants
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(BASE_DIR, 'models')
DATA_DIR = os.path.join(BASE_DIR, 'data')

RF_MODEL_PATH = os.path.join(MODELS_DIR, 'random_forest_model.pkl')
GB_MODEL_PATH = os.path.join(MODELS_DIR, 'gradient_boosting_model.pkl')
METADATA_PATH = os.path.join(MODELS_DIR, 'model_metadata.json')
DATASET_SUMMARY_PATH = os.path.join(DATA_DIR, 'dataset_summary.json')
KMEANS_SUMMARY_PATH = os.path.join(DATA_DIR, 'kmeans_summary.json')

# Expected feature list and sensible default ranges for validation
FEATURE_SPECS = [
    {
        'name': 'Temperature',
        'label': 'Temperature',
        'unit': '°C',
        'min': 10.0,
        'max': 50.0,
        'step': 0.1,
        'default': 32.0,
        'desc': 'Ambient air temperature in Celsius (noon observation).'
    },
    {
        'name': 'RH',
        'label': 'Relative Humidity',
        'unit': '%',
        'min': 10.0,
        'max': 100.0,
        'step': 0.5,
        'default': 60.0,
        'desc': 'Relative humidity percentage (lower humidity elevates fire danger).'
    },
    {
        'name': 'Ws',
        'label': 'Wind Speed',
        'unit': 'km/h',
        'min': 1.0,
        'max': 60.0,
        'step': 0.5,
        'default': 16.0,
        'desc': 'Average wind velocity at 10 meters height.'
    },
    {
        'name': 'Rain',
        'label': 'Rainfall',
        'unit': 'mm',
        'min': 0.0,
        'max': 60.0,
        'step': 0.1,
        'default': 0.0,
        'desc': 'Total precipitation over the previous 24 hours.'
    },
    {
        'name': 'FFMC',
        'label': 'Fine Fuel Moisture Code (FFMC)',
        'unit': 'index',
        'min': 20.0,
        'max': 100.0,
        'step': 0.1,
        'default': 85.0,
        'desc': 'Moisture content of surface litter & cured fine fuels (ignition ease).'
    },
    {
        'name': 'DMC',
        'label': 'Duff Moisture Code (DMC)',
        'unit': 'index',
        'min': 0.0,
        'max': 100.0,
        'step': 0.1,
        'default': 15.0,
        'desc': 'Moisture content of loosely compacted organic layers & duff.'
    },
    {
        'name': 'DC',
        'label': 'Drought Code (DC)',
        'unit': 'index',
        'min': 0.0,
        'max': 300.0,
        'step': 0.1,
        'default': 50.0,
        'desc': 'Moisture content of deep, compact organic layers & heavy logs.'
    },
    {
        'name': 'ISI',
        'label': 'Initial Spread Index (ISI)',
        'unit': 'index',
        'min': 0.0,
        'max': 60.0,
        'step': 0.1,
        'default': 5.5,
        'desc': 'Expected rate of fire spread without variable fuel influence.'
    },
    {
        'name': 'BUI',
        'label': 'Buildup Index (BUI)',
        'unit': 'index',
        'min': 0.0,
        'max': 100.0,
        'step': 0.1,
        'default': 18.0,
        'desc': 'Total fuel available for combustion (weighted combination of DMC & DC).'
    },
    {
        'name': 'FWI',
        'label': 'Fire Weather Index (FWI)',
        'unit': 'index',
        'min': 0.0,
        'max': 60.0,
        'step': 0.1,
        'default': 8.0,
        'desc': 'General fire intensity indicator combining ISI and BUI.'
    }
]

FEATURE_NAMES = [spec['name'] for spec in FEATURE_SPECS]

def load_artifacts():
    """Loads saved models, evaluation metadata, and summary stats."""
    if not (os.path.exists(RF_MODEL_PATH) and os.path.exists(GB_MODEL_PATH) and os.path.exists(METADATA_PATH)):
        # If models have not been trained yet, run pipeline
        from src.train_models import train_and_save_models
        from src.evaluate_models import evaluate_and_select_winner
        train_and_save_models()
        evaluate_and_select_winner()

    rf_model = joblib.load(RF_MODEL_PATH)
    gb_model = joblib.load(GB_MODEL_PATH)

    with open(METADATA_PATH, 'r') as f:
        metadata = json.load(f)

    dataset_summary = {}
    if os.path.exists(DATASET_SUMMARY_PATH):
        with open(DATASET_SUMMARY_PATH, 'r') as f:
            dataset_summary = json.load(f)

    kmeans_summary = {}
    if os.path.exists(KMEANS_SUMMARY_PATH):
        with open(KMEANS_SUMMARY_PATH, 'r') as f:
            kmeans_summary = json.load(f)

    return rf_model, gb_model, metadata, dataset_summary, kmeans_summary

# Load models and metadata on startup
rf_model, gb_model, metadata, dataset_summary, kmeans_summary = load_artifacts()

@app.route('/')
def home():
    """Page 1: Home page showing project overview, dataset stats, and model selection."""
    return render_template(
        'index.html',
        metadata=metadata,
        dataset_summary=dataset_summary,
        selected_model=metadata.get('selected_model', 'Random Forest'),
        rf_metrics=metadata['metrics']['random_forest'],
        gb_metrics=metadata['metrics']['gradient_boosting']
    )

@app.route('/predict_form')
def predict_form():
    """Page 2: Input page providing input fields for the 10 features."""
    return render_template(
        'input.html',
        features=FEATURE_SPECS,
        selected_model=metadata.get('selected_model', 'Random Forest')
    )

@app.route('/predict', methods=['POST'])
def predict():
    """
    Page 3: Prediction results page.
    Receives user input, evaluates both models, reports probabilities,
    checks agreement/disagreement, and yields authoritative verdict
    based on the automatically selected winning model.
    """
    input_values = {}
    errors = []

    # Validate each feature
    for spec in FEATURE_SPECS:
        f_name = spec['name']
        raw_val = request.form.get(f_name)
        if raw_val is None or raw_val.strip() == '':
            errors.append(f"Field '{spec['label']}' is required.")
            continue
        try:
            val = float(raw_val.strip())
            # Soft range check
            if val < 0 and spec['min'] >= 0:
                errors.append(f"'{spec['label']}' cannot be negative (entered: {val}).")
            input_values[f_name] = val
        except ValueError:
            errors.append(f"Invalid numeric value for '{spec['label']}': '{raw_val}'.")

    if errors:
        for err in errors:
            flash(err, 'error')
        return render_template('input.html', features=FEATURE_SPECS, form_data=request.form, selected_model=metadata.get('selected_model'))

    # Prepare DataFrame in exact training feature order and names
    input_df = pd.DataFrame([input_values])[FEATURE_NAMES]

    # 1. Random Forest prediction & probability
    rf_raw_pred = int(rf_model.predict(input_df)[0])
    rf_probas = rf_model.predict_proba(input_df)[0]
    rf_fire_prob = float(round(rf_probas[1] * 100, 2))
    rf_pred_label = 'Fire' if rf_raw_pred == 1 else 'Not Fire'

    # 2. Gradient Boosting prediction & probability
    gb_raw_pred = int(gb_model.predict(input_df)[0])
    gb_probas = gb_model.predict_proba(input_df)[0]
    gb_fire_prob = float(round(gb_probas[1] * 100, 2))
    gb_pred_label = 'Fire' if gb_raw_pred == 1 else 'Not Fire'

    # 3. Winning model's authoritative prediction & Runner-up analysis
    selected_winner = metadata.get('selected_model', 'Random Forest')
    is_rf_winner = 'Random Forest' in selected_winner

    if is_rf_winner:
        final_prediction_label = rf_pred_label
        final_probability = rf_fire_prob
        selected_model_metrics = metadata['metrics']['random_forest']
        runner_up_name = "Gradient Boosting"
        runner_up_metrics = metadata['metrics']['gradient_boosting']
        runner_up_pred = gb_pred_label
        runner_up_prob = gb_fire_prob
        loss_margin_metric = "ROC-AUC"
        winner_score = selected_model_metrics['roc_auc']
        runner_up_score = runner_up_metrics['roc_auc']
        score_diff_pct = round((winner_score - runner_up_score) * 100, 2)
        why_it_lost_summary = (
            f"Gradient Boosting tied with Random Forest on F1-Score ({selected_model_metrics['f1_score']*100:.2f}%) "
            f"and Recall (100.00%, 0 False Negatives). However, it lost on the tertiary tie-breaker: ROC-AUC. "
            f"Random Forest achieved a perfect 1.0000 (100.0%) discrimination score, while Gradient Boosting "
            f"achieved {runner_up_score:.4f} (96.41%), suffering a {score_diff_pct}% deficit due to less confident "
            f"probability calibration on borderline boundary conditions."
        )
    else:
        final_prediction_label = gb_pred_label
        final_probability = gb_fire_prob
        selected_model_metrics = metadata['metrics']['gradient_boosting']
        runner_up_name = "Random Forest"
        runner_up_metrics = metadata['metrics']['random_forest']
        runner_up_pred = rf_pred_label
        runner_up_prob = rf_fire_prob
        loss_margin_metric = "F1-Score"
        winner_score = selected_model_metrics['f1_score']
        runner_up_score = runner_up_metrics['f1_score']
        score_diff_pct = round((winner_score - runner_up_score) * 100, 2)
        why_it_lost_summary = (
            f"Random Forest attained a lower test F1-score ({runner_up_score:.4f} vs {winner_score:.4f}), "
            f"conferring the victory to Gradient Boosting on the primary evaluation metric."
        )

    # 4. Check for agreement or disagreement
    models_agree = (rf_raw_pred == gb_raw_pred)
    agreement_message = ""
    if models_agree:
        agreement_message = f"Both models in full agreement: {final_prediction_label}."
    else:
        agreement_message = (
            f"Model Disagreement: Random Forest predicts '{rf_pred_label}' ({rf_fire_prob}% fire prob) "
            f"while Gradient Boosting predicts '{gb_pred_label}' ({gb_fire_prob}% fire prob). "
            f"Authoritative decision defaults to the automatically selected superior model: {selected_winner}."
        )

    return render_template(
        'result.html',
        input_values=input_values,
        features=FEATURE_SPECS,
        rf_pred=rf_pred_label,
        rf_prob=rf_fire_prob,
        gb_pred=gb_pred_label,
        gb_prob=gb_fire_prob,
        selected_model=selected_winner,
        final_prediction=final_prediction_label,
        final_probability=final_probability,
        selected_metrics=selected_model_metrics,
        runner_up_name=runner_up_name,
        runner_up_metrics=runner_up_metrics,
        runner_up_pred=runner_up_pred,
        runner_up_prob=runner_up_prob,
        loss_margin_metric=loss_margin_metric,
        score_diff_pct=score_diff_pct,
        why_it_lost_summary=why_it_lost_summary,
        models_agree=models_agree,
        agreement_message=agreement_message,
        metadata=metadata
    )

@app.route('/syllabus')
def syllabus():
    """Educational syllabus mapping page (M1 to M6) detailing theory vs implementation."""
    return render_template(
        'syllabus.html',
        metadata=metadata,
        dataset_summary=dataset_summary,
        kmeans_summary=kmeans_summary
    )

@app.route('/api/predict', methods=['POST'])
def api_predict():
    """RESTful API endpoint for prediction (supports automated testing and M6 monitoring)."""
    try:
        data = request.get_json(force=True)
        vector = []
        for f in FEATURE_NAMES:
            if f not in data:
                return jsonify({'error': f"Missing feature: {f}"}), 400
            vector.append(float(data[f]))

        input_df = pd.DataFrame([[float(data[f]) for f in FEATURE_NAMES]], columns=FEATURE_NAMES)
        rf_pred = int(rf_model.predict(input_df)[0])
        rf_prob = float(rf_model.predict_proba(input_df)[0][1])

        gb_pred = int(gb_model.predict(input_df)[0])
        gb_prob = float(gb_model.predict_proba(input_df)[0][1])

        is_rf_winner = 'Random Forest' in metadata.get('selected_model', 'Random Forest')
        final_pred = rf_pred if is_rf_winner else gb_pred
        final_prob = rf_prob if is_rf_winner else gb_prob

        return jsonify({
            'selected_model': metadata.get('selected_model'),
            'final_prediction': 'Fire' if final_pred == 1 else 'Not Fire',
            'final_fire_probability': round(final_prob, 4),
            'models_agree': bool(rf_pred == gb_pred),
            'random_forest': {
                'prediction': 'Fire' if rf_pred == 1 else 'Not Fire',
                'probability': round(rf_prob, 4)
            },
            'gradient_boosting': {
                'prediction': 'Fire' if gb_pred == 1 else 'Not Fire',
                'probability': round(gb_prob, 4)
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # Run development server on port 5000
    app.run(host='127.0.0.1', port=5000, debug=True)
