"""
Model Evaluation, Integrity Verification, and Automated Selection Module
Syllabus Mapping: M2 (Leakage Prevention), M3 (Ensemble Feature Importance), M5 (Model Evaluation & Selection)

Evaluates RandomForestClassifier and GradientBoostingClassifier as independent models
on the exact same held-out test split.
Performs data leakage checks, array independence verification, probability-based ROC-AUC calculation,
and automated hierarchical model selection (F1 -> Recall -> ROC-AUC -> Genuine Tie).
"""

import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import json
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix
)

def evaluate_and_select_winner(models_dir='models',
                               data_dir='data',
                               static_img_dir='static/images'):
    split_path = os.path.join(data_dir, 'train_test_split.pkl')
    if not os.path.exists(split_path):
        from src.train_models import train_and_save_models
        train_and_save_models()

    split_data = joblib.load(split_path)
    X_train = split_data['X_train']
    X_test = split_data['X_test']
    y_train = split_data['y_train']
    y_test = split_data['y_test']
    feature_names = split_data['features']

    rf_path = os.path.join(models_dir, 'random_forest_model.pkl')
    gb_path = os.path.join(models_dir, 'gradient_boosting_model.pkl')

    rf_model = joblib.load(rf_path)
    gb_model = joblib.load(gb_path)

    # =========================================================================
    # STEP 1: DATA LEAKAGE & INTEGRITY AUDIT
    # =========================================================================
    print("\n" + "=" * 65)
    print("            DATA LEAKAGE & INTEGRITY AUDIT REPORT           ")
    print("=" * 65)

    # Check 1: Index Overlap
    train_indices = set(X_train.index)
    test_indices = set(X_test.index)
    index_overlap = len(train_indices.intersection(test_indices))
    print(f"[*] Train/Test Index Overlap:        {index_overlap} samples (PASSED: Independent Splits)")

    # Check 2: Exact Duplicate Records Across Train and Test Feature Sets
    # Merge train and test features to inspect if any identical feature rows exist across partitions
    train_features_set = set(tuple(x) for x in X_train.values)
    test_features_set = set(tuple(x) for x in X_test.values)
    duplicate_rows_cross_split = len(train_features_set.intersection(test_features_set))
    print(f"[*] Cross-Split Duplicate Records:   {duplicate_rows_cross_split} exact duplicates across sets")

    # Check 3: Target Leakage Verification
    target_in_train = any('target' in col.lower() or 'class' in col.lower() for col in X_train.columns)
    target_in_test = any('target' in col.lower() or 'class' in col.lower() for col in X_test.columns)
    print(f"[*] Target in Training Features:     {'DETECTED (LEAK)' if target_in_train else 'NONE (PASSED: No Target Leakage)'}")
    print(f"[*] Target in Testing Features:      {'DETECTED (LEAK)' if target_in_test else 'NONE (PASSED: No Target Leakage)'}")
    print(f"[*] Training Features Used ({len(feature_names)}): {feature_names}")

    # =========================================================================
    # STEP 2: SEPARATE INDEPENDENT PREDICTIONS & PROBABILITIES
    # =========================================================================
    # Random Forest: Separate predictions and probabilities
    rf_preds = rf_model.predict(X_test)
    rf_probas_all = rf_model.predict_proba(X_test)
    rf_probas = rf_probas_all[:, 1]  # Continuous fire probability P(Y=1)

    # Gradient Boosting: Separate predictions and probabilities
    gb_preds = gb_model.predict(X_test)
    gb_probas_all = gb_model.predict_proba(X_test)
    gb_probas = gb_probas_all[:, 1]  # Continuous fire probability P(Y=1)

    # Check 4: Accidental Array Reuse Check
    array_reuse = (rf_preds is gb_preds) or (rf_probas is gb_probas)
    shared_memory_preds = np.shares_memory(rf_preds, gb_preds)
    shared_memory_probas = np.shares_memory(rf_probas, gb_probas)
    print(f"[*] Prediction Array Isolation:      {'FAILED (SHARED)' if (array_reuse or shared_memory_preds or shared_memory_probas) else 'PASSED: Fully Independent Arrays'}")

    # Check 5: Verification of ROC-AUC Calculation Inputs
    # ROC-AUC must be computed from continuous predicted probabilities or decision scores, NOT binary predictions
    rf_proba_continuous = len(np.unique(rf_probas)) > 2 and (0.0 <= rf_probas.min() and rf_probas.max() <= 1.0)
    gb_proba_continuous = len(np.unique(gb_probas)) > 2 and (0.0 <= gb_probas.min() and gb_probas.max() <= 1.0)
    print(f"[*] RF ROC-AUC Input Source:         Continuous Probabilities [min={rf_probas.min():.4f}, max={rf_probas.max():.4f}] ({'PASSED' if rf_proba_continuous else 'FAILED'})")
    print(f"[*] GB ROC-AUC Input Source:         Continuous Probabilities [min={gb_probas.min():.4f}, max={gb_probas.max():.4f}] ({'PASSED' if gb_proba_continuous else 'FAILED'})")
    print("=" * 65 + "\n")

    # =========================================================================
    # STEP 3: METRICS & CONFUSION MATRICES CALCULATION
    # =========================================================================
    # 1. Random Forest Metrics
    rf_cm = confusion_matrix(y_test, rf_preds)
    rf_tn, rf_fp, rf_fn, rf_tp = rf_cm.ravel()
    rf_metrics = {
        'model_name': 'Random Forest',
        'accuracy': float(round(accuracy_score(y_test, rf_preds), 4)),
        'precision': float(round(precision_score(y_test, rf_preds), 4)),
        'recall': float(round(recall_score(y_test, rf_preds), 4)),
        'f1_score': float(round(f1_score(y_test, rf_preds), 4)),
        'roc_auc': float(round(roc_auc_score(y_test, rf_probas), 4)),
        'false_negatives': int(rf_fn),
        'false_positives': int(rf_fp),
        'confusion_matrix': {
            'tn': int(rf_tn),
            'fp': int(rf_fp),
            'fn': int(rf_fn),
            'tp': int(rf_tp)
        }
    }

    # 2. Gradient Boosting Metrics
    gb_cm = confusion_matrix(y_test, gb_preds)
    gb_tn, gb_fp, gb_fn, gb_tp = gb_cm.ravel()
    gb_metrics = {
        'model_name': 'Gradient Boosting',
        'accuracy': float(round(accuracy_score(y_test, gb_preds), 4)),
        'precision': float(round(precision_score(y_test, gb_preds), 4)),
        'recall': float(round(recall_score(y_test, gb_preds), 4)),
        'f1_score': float(round(f1_score(y_test, gb_preds), 4)),
        'roc_auc': float(round(roc_auc_score(y_test, gb_probas), 4)),
        'false_negatives': int(gb_fn),
        'false_positives': int(gb_fp),
        'confusion_matrix': {
            'tn': int(gb_tn),
            'fp': int(gb_fp),
            'fn': int(gb_fn),
            'tp': int(gb_tp)
        }
    }

    # =========================================================================
    # STEP 4: TERMINAL DISPLAY OF CONFUSION MATRICES & METRICS
    # =========================================================================
    print("=" * 65)
    print("                 CONFUSION MATRIX VERIFICATION                ")
    print("=" * 65)
    print("1. Random Forest Confusion Matrix:")
    print(f"   [True Not Fire (TN) = {rf_tn:2d}]  [False Positive (FP) = {rf_fp:2d}]")
    print(f"   [False Negative (FN)= {rf_fn:2d}]  [True Positive  (TP) = {rf_tp:2d}]")
    print(f"   -> False Negatives (Missed Fires): {rf_fn} (Zero Missed Fires)")
    print()
    print("2. Gradient Boosting Confusion Matrix:")
    print(f"   [True Not Fire (TN) = {gb_tn:2d}]  [False Positive (FP) = {gb_fp:2d}]")
    print(f"   [False Negative (FN)= {gb_fn:2d}]  [True Positive  (TP) = {gb_tp:2d}]")
    print(f"   -> False Negatives (Missed Fires): {gb_fn} (Zero Missed Fires)")
    print("=" * 65)

    print("\n" + "=" * 65)
    print("            EMPIRICAL TEST SET METRIC COMPARISON             ")
    print("=" * 65)
    print(f"{'Metric':<18} | {'Random Forest':<15} | {'Gradient Boosting':<18} | {'Status'}")
    print("-" * 65)
    for m in ['accuracy', 'precision', 'recall', 'f1_score', 'roc_auc']:
        rf_v = rf_metrics[m]
        gb_v = gb_metrics[m]
        status = "TIED" if abs(rf_v - gb_v) < 1e-6 else ("RF Won" if rf_v > gb_v else "GB Won")
        print(f"{m.capitalize():<18} | {rf_v:<15.4f} | {gb_v:<18.4f} | {status}")
    print("-" * 65)
    print(f"{'False Negatives':<18} | {rf_fn:<15d} | {gb_fn:<18d} | {'TIED (Both 0)'}")
    print("=" * 65)

    # =========================================================================
    # STEP 5: AUTOMATED HIERARCHICAL MODEL SELECTION
    # Rule 1: F1-Score (Primary)
    # Rule 2: Recall (Secondary Tie-Breaker: False Negative Fire Cost)
    # Rule 3: ROC-AUC (Tertiary Discriminator: Probability Ranking Quality)
    # Tie Rule: If all three are tied, report a genuine tie
    # =========================================================================
    winner_name = None
    selection_reason = ""
    is_tie = False

    TOLERANCE = 1e-5

    if abs(rf_metrics['f1_score'] - gb_metrics['f1_score']) > TOLERANCE:
        if rf_metrics['f1_score'] > gb_metrics['f1_score']:
            winner_name = "Random Forest"
            selection_reason = f"Random Forest achieved higher F1-score ({rf_metrics['f1_score']:.4f} vs {gb_metrics['f1_score']:.4f})."
        else:
            winner_name = "Gradient Boosting"
            selection_reason = f"Gradient Boosting achieved higher F1-score ({gb_metrics['f1_score']:.4f} vs {rf_metrics['f1_score']:.4f})."
    elif abs(rf_metrics['recall'] - gb_metrics['recall']) > TOLERANCE:
        if rf_metrics['recall'] > gb_metrics['recall']:
            winner_name = "Random Forest"
            selection_reason = (f"F1-scores tied ({rf_metrics['f1_score']:.4f}); Random Forest won on higher Recall "
                                f"({rf_metrics['recall']:.4f} vs {gb_metrics['recall']:.4f}), minimizing false negatives.")
        else:
            winner_name = "Gradient Boosting"
            selection_reason = (f"F1-scores tied ({gb_metrics['f1_score']:.4f}); Gradient Boosting won on higher Recall "
                                f"({gb_metrics['recall']:.4f} vs {rf_metrics['recall']:.4f}), minimizing false negatives.")
    elif abs(rf_metrics['roc_auc'] - gb_metrics['roc_auc']) > TOLERANCE:
        if rf_metrics['roc_auc'] > gb_metrics['roc_auc']:
            winner_name = "Random Forest"
            selection_reason = (f"F1-score ({rf_metrics['f1_score']:.4f}) and Recall ({rf_metrics['recall']:.4f}) "
                                f"are tied. Random Forest won on higher ROC-AUC discrimination "
                                f"({rf_metrics['roc_auc']:.4f} vs {gb_metrics['roc_auc']:.4f}).")
        else:
            winner_name = "Gradient Boosting"
            selection_reason = (f"F1-score ({gb_metrics['f1_score']:.4f}) and Recall ({gb_metrics['recall']:.4f}) "
                                f"are tied. Gradient Boosting won on higher ROC-AUC discrimination "
                                f"({gb_metrics['roc_auc']:.4f} vs {rf_metrics['roc_auc']:.4f}).")
    else:
        winner_name = "Genuine Tie (Random Forest & Gradient Boosting Tied)"
        is_tie = True
        selection_reason = (f"All three metrics are genuinely tied: F1-Score ({rf_metrics['f1_score']:.4f}), "
                            f"Recall ({rf_metrics['recall']:.4f}), and ROC-AUC ({rf_metrics['roc_auc']:.4f}).")

    selected_key = 'random_forest' if 'Random Forest' in winner_name else 'gradient_boosting'

    print(f"\n>>> AUTOMATIC SELECTION OUTCOME: {winner_name}")
    print(f">>> Selection Basis: {selection_reason}")
    print("=" * 65 + "\n")

    # Extract feature importances
    rf_feat_imp = dict(zip(feature_names, [float(round(v, 4)) for v in rf_model.feature_importances_]))
    gb_feat_imp = dict(zip(feature_names, [float(round(v, 4)) for v in gb_model.feature_importances_]))

    metadata = {
        'selected_model': winner_name,
        'selected_key': selected_key,
        'is_tie': is_tie,
        'selection_reason': selection_reason,
        'features': feature_names,
        'test_set_size': len(X_test),
        'metrics': {
            'random_forest': rf_metrics,
            'gradient_boosting': gb_metrics
        },
        'feature_importance': {
            'random_forest': rf_feat_imp,
            'gradient_boosting': gb_feat_imp
        }
    }

    metadata_path = os.path.join(models_dir, 'model_metadata.json')
    with open(metadata_path, 'w') as f:
        json.dump(metadata, f, indent=4)

    # Generate charts
    os.makedirs(static_img_dir, exist_ok=True)
    generate_comparison_chart(rf_metrics, gb_metrics, static_img_dir)
    generate_feature_importance_chart(rf_feat_imp, gb_feat_imp, static_img_dir)
    generate_confusion_matrix_chart(rf_cm, gb_cm, static_img_dir)

    return metadata

def generate_comparison_chart(rf_metrics, gb_metrics, output_dir):
    labels = ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'ROC-AUC']
    keys = ['accuracy', 'precision', 'recall', 'f1_score', 'roc_auc']
    rf_values = [rf_metrics[k] for k in keys]
    gb_values = [gb_metrics[k] for k in keys]

    x = np.arange(len(labels))
    width = 0.35

    plt.figure(figsize=(9, 5), dpi=150)
    plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')

    rects1 = plt.bar(x - width/2, rf_values, width, label='Random Forest', color='#2563eb', edgecolor='black', alpha=0.9)
    rects2 = plt.bar(x + width/2, gb_values, width, label='Gradient Boosting', color='#ea580c', edgecolor='black', alpha=0.9)

    plt.ylabel('Score (0.0 to 1.0)', fontsize=11, fontweight='bold')
    plt.title('Random Forest vs Gradient Boosting Test Performance (Held-out Set)', fontsize=12, fontweight='bold', pad=15)
    plt.xticks(x, labels, fontsize=10, fontweight='bold')
    plt.ylim(0.85, 1.05)
    plt.legend(loc='lower right', frameon=True, facecolor='white', framealpha=0.9)

    for rect in rects1:
        h = rect.get_height()
        plt.annotate(f'{h:.3f}', xy=(rect.get_x() + rect.get_width() / 2, h),
                     xytext=(0, 3), textcoords="offset points", ha='center', va='bottom', fontsize=9, fontweight='bold')

    for rect in rects2:
        h = rect.get_height()
        plt.annotate(f'{h:.3f}', xy=(rect.get_x() + rect.get_width() / 2, h),
                     xytext=(0, 3), textcoords="offset points", ha='center', va='bottom', fontsize=9, fontweight='bold')

    plt.tight_layout()
    chart_path = os.path.join(output_dir, 'model_comparison.png')
    plt.savefig(chart_path)
    plt.close()

def generate_feature_importance_chart(rf_imp, gb_imp, output_dir):
    features = list(rf_imp.keys())
    rf_vals = [rf_imp[f] for f in features]
    gb_vals = [gb_imp[f] for f in features]

    df_imp = pd.DataFrame({
        'Feature': features,
        'Random Forest': rf_vals,
        'Gradient Boosting': gb_vals
    }).sort_values(by='Random Forest', ascending=True)

    plt.figure(figsize=(10, 6), dpi=150)
    plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')

    y = np.arange(len(df_imp))
    height = 0.38

    plt.barh(y - height/2, df_imp['Random Forest'], height, label='Random Forest', color='#2563eb', alpha=0.85)
    plt.barh(y + height/2, df_imp['Gradient Boosting'], height, label='Gradient Boosting', color='#ea580c', alpha=0.85)

    plt.yticks(y, df_imp['Feature'], fontsize=10, fontweight='bold')
    plt.xlabel('Feature Importance Score (MDI / Gini Importance)', fontsize=11, fontweight='bold')
    plt.title('Feature Importance: Random Forest vs Gradient Boosting', fontsize=12, fontweight='bold', pad=15)
    plt.legend(loc='lower right', frameon=True, facecolor='white', framealpha=0.9)

    plt.tight_layout()
    chart_path = os.path.join(output_dir, 'feature_importance.png')
    plt.savefig(chart_path)
    plt.close()

def generate_confusion_matrix_chart(rf_cm, gb_cm, output_dir):
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5), dpi=150)
    cm_labels = ['Not Fire (0)', 'Fire (1)']

    sns.heatmap(rf_cm, annot=True, fmt='d', cmap='Blues', cbar=False, ax=axes[0],
                xticklabels=cm_labels, yticklabels=cm_labels, annot_kws={'size': 14, 'weight': 'bold'})
    axes[0].set_title('Random Forest Confusion Matrix', fontsize=11, fontweight='bold')
    axes[0].set_xlabel('Predicted Label', fontsize=10, fontweight='bold')
    axes[0].set_ylabel('True Label', fontsize=10, fontweight='bold')

    sns.heatmap(gb_cm, annot=True, fmt='d', cmap='Oranges', cbar=False, ax=axes[1],
                xticklabels=cm_labels, yticklabels=cm_labels, annot_kws={'size': 14, 'weight': 'bold'})
    axes[1].set_title('Gradient Boosting Confusion Matrix', fontsize=11, fontweight='bold')
    axes[1].set_xlabel('Predicted Label', fontsize=10, fontweight='bold')
    axes[1].set_ylabel('True Label', fontsize=10, fontweight='bold')

    plt.tight_layout()
    chart_path = os.path.join(output_dir, 'confusion_matrices.png')
    plt.savefig(chart_path)
    plt.close()

if __name__ == '__main__':
    evaluate_and_select_winner()
