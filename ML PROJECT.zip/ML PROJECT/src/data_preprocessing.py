"""
Data Preprocessing Module for Forest Fire Risk Prediction
Dataset: Algerian Forest Fires Dataset (Bejaia & Sidi-Bel Abbes Regions)
Syllabus Mapping: M1 (Data Pipeline) & M2 (Missing-value Handling & Leakage Prevention)
"""

import os
import json
import pandas as pd
import numpy as np

# Define feature columns strictly used for weather and fire weather index prediction
FEATURE_COLUMNS = [
    'Temperature',
    'RH',
    'Ws',
    'Rain',
    'FFMC',
    'DMC',
    'DC',
    'ISI',
    'BUI',
    'FWI'
]

TARGET_COLUMN = 'Classes'

def clean_and_load_dataset(raw_csv_path='Algerian_forest_fires_dataset_UPDATE.csv', output_dir='data'):
    """
    Cleans the raw Algerian Forest Fires dataset:
    - Filters region header rows and duplicate CSV headers
    - Fixes known malformed record with '14.6 9'
    - Strips whitespace in column names and string fields
    - Standardizes target classes: 'fire' -> 1, 'not fire' -> 0
    - Converts feature columns to numeric types
    - Saves cleaned dataset and summary JSON
    """
    if not os.path.exists(raw_csv_path):
        raise FileNotFoundError(f"Raw dataset file not found at: {raw_csv_path}")

    cleaned_lines = []
    region = 0  # 0 for Bejaia, 1 for Sidi-Bel Abbes
    region_names = {0: 'Bejaia', 1: 'Sidi-Bel Abbes'}

    with open(raw_csv_path, 'r', encoding='utf-8', errors='ignore') as f:
        for line_num, line in enumerate(f, start=1):
            line_str = line.strip()
            if not line_str:
                continue

            # Detect region demarcation
            if 'Bejaia Region' in line_str:
                region = 0
                continue
            if 'Sidi-Bel Abbes Region' in line_str:
                region = 1
                continue

            # Header detection
            if 'Temperature' in line_str and 'RH' in line_str:
                if not cleaned_lines:
                    # Append main header with Region tracking
                    cleaned_lines.append(line_str + ',Region')
                continue

            # Fix malformed record in UCI dataset where DC and ISI are separated by space instead of comma
            if '14.6 9' in line_str:
                line_str = line_str.replace('14.6 9', '14.6,9')

            cleaned_lines.append(line_str + f',{region}')

    # Parse into DataFrame
    import io
    df = pd.read_csv(io.StringIO('\n'.join(cleaned_lines)))

    # Strip whitespace from column names
    df.columns = df.columns.str.strip()

    # Strip whitespace from all string columns
    for col in df.columns:
        if df[col].dtype == object or isinstance(df[col].dtype, pd.StringDtype):
            df[col] = df[col].astype(str).str.strip()

    # Clean target column: lowercase and strip
    df[TARGET_COLUMN] = df[TARGET_COLUMN].str.lower()
    
    # Map target: 'fire' -> 1, 'not fire' -> 0
    def map_class(val):
        val = str(val).strip()
        if 'not' in val:
            return 0
        elif 'fire' in val:
            return 1
        return np.nan

    df['target'] = df[TARGET_COLUMN].apply(map_class)

    # Convert feature columns to numeric
    for col in FEATURE_COLUMNS:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    # Remove any unparseable rows
    initial_count = len(df)
    df = df.dropna(subset=FEATURE_COLUMNS + ['target'])
    df['target'] = df['target'].astype(int)
    final_count = len(df)

    # Class distribution
    fire_count = int((df['target'] == 1).sum())
    not_fire_count = int((df['target'] == 0).sum())

    os.makedirs(output_dir, exist_ok=True)
    cleaned_csv_path = os.path.join(output_dir, 'cleaned_algerian_fires.csv')
    df.to_csv(cleaned_csv_path, index=False)

    summary = {
        'total_records': final_count,
        'features': FEATURE_COLUMNS,
        'target_column': 'target',
        'class_distribution': {
            'Fire': fire_count,
            'Not Fire': not_fire_count,
            'Fire_percentage': round((fire_count / final_count) * 100, 2),
            'Not_Fire_percentage': round((not_fire_count / final_count) * 100, 2)
        },
        'regions': {
            'Bejaia_records': int((df['Region'] == 0).sum()),
            'Sidi_Bel_Abbes_records': int((df['Region'] == 1).sum())
        },
        'feature_statistics': df[FEATURE_COLUMNS].describe().to_dict()
    }

    summary_path = os.path.join(output_dir, 'dataset_summary.json')
    with open(summary_path, 'w') as f:
        json.dump(summary, f, indent=4)

    print(f"=== Dataset Preprocessing Complete ===")
    print(f"Raw rows parsed: {initial_count}")
    print(f"Cleaned valid records: {final_count}")
    print(f"Features ({len(FEATURE_COLUMNS)}): {FEATURE_COLUMNS}")
    print(f"Class Distribution: Fire={fire_count} ({summary['class_distribution']['Fire_percentage']}%), "
          f"Not Fire={not_fire_count} ({summary['class_distribution']['Not_Fire_percentage']}%)")
    print(f"Saved cleaned CSV to: {cleaned_csv_path}")
    print(f"Saved summary JSON to: {summary_path}")

    return df, summary

if __name__ == '__main__':
    clean_and_load_dataset()
