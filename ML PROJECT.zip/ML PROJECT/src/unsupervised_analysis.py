"""
Unsupervised Learning Exploratory Module (K-Means Clustering)
Syllabus Mapping: M4 (Unsupervised Learning Concepts)
Note: This module is strictly for exploratory pattern discovery and data analysis.
It is NOT used as a third prediction model for the web application.
"""

import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import json
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from src.data_preprocessing import FEATURE_COLUMNS

def run_kmeans_exploratory_analysis(cleaned_csv='data/cleaned_algerian_fires.csv',
                                    output_img_dir='static/images',
                                    data_dir='data'):
    """
    Performs K-Means clustering on the continuous weather features,
    compares discovered clusters against fire/no-fire occurrence,
    and saves cluster visualization.
    """
    if not os.path.exists(cleaned_csv):
        from src.data_preprocessing import clean_and_load_dataset
        df, _ = clean_and_load_dataset()
    else:
        df = pd.read_csv(cleaned_csv)

    X = df[FEATURE_COLUMNS]
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Fit K-Means with k=2 clusters (exploring natural split in weather profiles)
    kmeans = KMeans(n_clusters=2, random_state=42, n_init=10)
    clusters = kmeans.fit_predict(X_scaled)
    df['cluster'] = clusters

    # Dimensionality reduction via PCA for 2D visualization
    pca = PCA(n_components=2, random_state=42)
    X_pca = pca.fit_transform(X_scaled)

    os.makedirs(output_img_dir, exist_ok=True)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.8), dpi=150)
    plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')

    # Plot 1: K-Means Discovered Clusters
    colors = ['#2563eb', '#dc2626']
    for c in range(2):
        mask = clusters == c
        ax1.scatter(X_pca[mask, 0], X_pca[mask, 1],
                    label=f'Cluster {c} (n={mask.sum()})',
                    color=colors[c], alpha=0.7, edgecolors='black', s=45)

    # Plot cluster centroids
    pca_centroids = pca.transform(kmeans.cluster_centers_)
    ax1.scatter(pca_centroids[:, 0], pca_centroids[:, 1],
                s=180, c='yellow', marker='X', edgecolor='black', label='Centroids', zorder=5)

    ax1.set_title('M4 Exploratory: K-Means Discovered Clusters (PCA 2D)', fontsize=11, fontweight='bold')
    ax1.set_xlabel(f'PCA Component 1 ({pca.explained_variance_ratio_[0]*100:.1f}% var)', fontsize=10)
    ax1.set_ylabel(f'PCA Component 2 ({pca.explained_variance_ratio_[1]*100:.1f}% var)', fontsize=10)
    ax1.legend(loc='upper right')

    # Plot 2: True Ground Truth Fire / Not Fire
    gt_colors = {0: '#16a34a', 1: '#ea580c'}
    gt_labels = {0: 'Actual: Not Fire', 1: 'Actual: Fire'}
    for target_val in [0, 1]:
        mask = df['target'] == target_val
        ax2.scatter(X_pca[mask, 0], X_pca[mask, 1],
                    label=f'{gt_labels[target_val]} (n={mask.sum()})',
                    color=gt_colors[target_val], alpha=0.7, edgecolors='black', s=45)

    ax2.set_title('Supervised Ground Truth: Fire vs Not Fire (PCA 2D)', fontsize=11, fontweight='bold')
    ax2.set_xlabel(f'PCA Component 1 ({pca.explained_variance_ratio_[0]*100:.1f}% var)', fontsize=10)
    ax2.set_ylabel(f'PCA Component 2 ({pca.explained_variance_ratio_[1]*100:.1f}% var)', fontsize=10)
    ax2.legend(loc='upper right')

    plt.tight_layout()
    chart_path = os.path.join(output_img_dir, 'kmeans_clusters.png')
    plt.savefig(chart_path)
    plt.close()

    # Calculate alignment with true fire target
    c0_fire_ratio = float(round((df[df['cluster'] == 0]['target'] == 1).mean() * 100, 2))
    c1_fire_ratio = float(round((df[df['cluster'] == 1]['target'] == 1).mean() * 100, 2))

    summary = {
        'module': 'M4 Unsupervised Learning',
        'algorithm': 'K-Means (k=2)',
        'purpose': 'Exploratory data analysis & weather profile clustering without labels',
        'is_prediction_model': False,
        'cluster_0_size': int((clusters == 0).sum()),
        'cluster_1_size': int((clusters == 1).sum()),
        'cluster_0_fire_concentration_pct': c0_fire_ratio,
        'cluster_1_fire_concentration_pct': c1_fire_ratio,
        'pca_variance_explained_ratio': [float(round(v, 4)) for v in pca.explained_variance_ratio_]
    }

    summary_path = os.path.join(data_dir, 'kmeans_summary.json')
    with open(summary_path, 'w') as f:
        json.dump(summary, f, indent=4)

    print(f"=== K-Means Exploratory Analysis Complete (M4) ===")
    print(f"Cluster 0: {summary['cluster_0_size']} samples (Fire occurrence: {c0_fire_ratio}%)")
    print(f"Cluster 1: {summary['cluster_1_size']} samples (Fire occurrence: {c1_fire_ratio}%)")
    print(f"Cluster visualization saved to: {chart_path}")
    print(f"Summary JSON saved to: {summary_path}")

    return summary

if __name__ == '__main__':
    run_kmeans_exploratory_analysis()
