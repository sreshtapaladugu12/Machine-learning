"""
Model Training Module for Forest Fire Risk Prediction
Syllabus Mapping: M2 (Leakage Prevention) & M3 (Random Forest & Gradient Boosting)
Trains exactly two supervised models without hyperparameter tuning:
1. RandomForestClassifier
2. GradientBoostingClassifier
"""

import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from src.data_preprocessing import FEATURE_COLUMNS

def train_and_save_models(cleaned_csv_path='data/cleaned_algerian_fires.csv',
                          models_dir='models',
                          data_dir='data',
                          test_size=0.25,
                          random_state=42):
    """
    Splits the dataset using stratified sampling to prevent data leakage,
    trains RandomForestClassifier and GradientBoostingClassifier,
    and serializes the models and test split for evaluation.
    """
    if not os.path.exists(cleaned_csv_path):
        from src.data_preprocessing import clean_and_load_dataset
        df, _ = clean_and_load_dataset()
    else:
        df = pd.read_csv(cleaned_csv_path)

    X = df[FEATURE_COLUMNS]
    y = df['target']

    # Stratified split ensures balanced representation of fire (1) and not fire (0)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=test_size,
        random_state=random_state,
        stratify=y
    )

    print(f"=== Dataset Split Summary ===")
    print(f"Total samples: {len(df)}")
    print(f"Training samples: {len(X_train)} (Fire: {(y_train == 1).sum()}, Not Fire: {(y_train == 0).sum()})")
    print(f"Testing samples:  {len(X_test)} (Fire: {(y_test == 1).sum()}, Not Fire: {(y_test == 0).sum()})")

    # 1. Random Forest Classifier (No hyperparameter tuning, default parameters)
    print("\nTraining RandomForestClassifier...")
    rf_model = RandomForestClassifier(random_state=random_state)
    rf_model.fit(X_train, y_train)

    # 2. Gradient Boosting Classifier (No hyperparameter tuning, default parameters)
    print("Training GradientBoostingClassifier...")
    gb_model = GradientBoostingClassifier(random_state=random_state)
    gb_model.fit(X_train, y_train)

    # Save models
    os.makedirs(models_dir, exist_ok=True)
    rf_path = os.path.join(models_dir, 'random_forest_model.pkl')
    gb_path = os.path.join(models_dir, 'gradient_boosting_model.pkl')

    joblib.dump(rf_model, rf_path)
    joblib.dump(gb_model, gb_path)

    # Save split data for evaluation pipeline
    os.makedirs(data_dir, exist_ok=True)
    split_data = {
        'X_train': X_train,
        'X_test': X_test,
        'y_train': y_train,
        'y_test': y_test,
        'features': FEATURE_COLUMNS,
        'test_size': test_size,
        'random_state': random_state
    }
    split_path = os.path.join(data_dir, 'train_test_split.pkl')
    joblib.dump(split_data, split_path)

    print(f"Successfully saved RandomForestClassifier to: {rf_path}")
    print(f"Successfully saved GradientBoostingClassifier to: {gb_path}")
    print(f"Saved held-out test data to: {split_path}")

    return rf_model, gb_model, split_data

if __name__ == '__main__':
    train_and_save_models()
