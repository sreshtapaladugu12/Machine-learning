/**
 * Forest Fire Risk Prediction System
 * Client-side script: Presets and dynamic form validation
 */

document.addEventListener('DOMContentLoaded', () => {
    // Presets definition based on actual Algerian dataset samples
    const presets = {
        highRisk: {
            // Actual high fire risk observation from Sidi-Bel Abbes (row 77 / Aug 17)
            Temperature: 37.0,
            RH: 37.0,
            Ws: 18.0,
            Rain: 0.0,
            FFMC: 89.3,
            DMC: 16.0,
            DC: 100.7,
            ISI: 9.7,
            BUI: 22.9,
            FWI: 14.6
        },
        lowRisk: {
            // Actual low fire risk / rain observation from Bejaia (row 9 / Jun 09)
            Temperature: 25.0,
            RH: 88.0,
            Ws: 13.0,
            Rain: 0.2,
            FFMC: 52.9,
            DMC: 7.9,
            DC: 38.8,
            ISI: 0.4,
            BUI: 10.5,
            FWI: 0.3
        },
        borderline: {
            // Borderline condition from dataset (row 72) where models exhibit fine boundary discrimination
            Temperature: 35.0,
            RH: 51.0,
            Ws: 13.0,
            Rain: 0.3,
            FFMC: 81.3,
            DMC: 15.6,
            DC: 75.1,
            ISI: 2.5,
            BUI: 20.7,
            FWI: 4.2
        }
    };

    // Preset button event listeners
    const presetButtons = document.querySelectorAll('.btn-preset[data-preset]');
    presetButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const presetKey = btn.getAttribute('data-preset');
            if (presets[presetKey]) {
                applyPreset(presets[presetKey]);
            }
        });
    });

    function applyPreset(data) {
        for (const [key, val] of Object.entries(data)) {
            const input = document.getElementById(`input_${key}`);
            if (input) {
                input.value = val;
                // Add brief visual pulse highlight
                input.style.backgroundColor = '#ecfdf5';
                input.style.borderColor = '#10b981';
                setTimeout(() => {
                    input.style.backgroundColor = '';
                    input.style.borderColor = '';
                }, 400);
            }
        }
    }

    // Input form validation & formatting
    const predictionForm = document.getElementById('predictionForm');
    if (predictionForm) {
        predictionForm.addEventListener('submit', (e) => {
            const inputs = predictionForm.querySelectorAll('.form-input');
            let hasError = false;

            inputs.forEach(input => {
                const val = parseFloat(input.value);
                const min = parseFloat(input.min);
                const max = parseFloat(input.max);

                if (isNaN(val)) {
                    input.style.borderColor = '#ef4444';
                    hasError = true;
                } else if (!isNaN(min) && val < min) {
                    input.style.borderColor = '#ef4444';
                    hasError = true;
                } else if (!isNaN(max) && val > max) {
                    input.style.borderColor = '#ef4444';
                    hasError = true;
                } else {
                    input.style.borderColor = '';
                }
            });

            if (hasError) {
                e.preventDefault();
                alert('Please verify all highlighted input fields have valid numbers within specified ranges.');
            }
        });
    }
});
