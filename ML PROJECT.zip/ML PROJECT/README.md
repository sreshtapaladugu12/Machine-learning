# Forest Fire Risk Prediction Using Random Forest and Gradient-Boosted Trees

An end-to-end Machine Learning web application developed for B.Tech 2nd-Year Machine Learning Curriculum (Modules M1–M6). This project predicts forest fire risk using real meteorological and Canadian Fire Weather Index (FWI) data from Algeria, evaluates two ensemble learning architectures (**Random Forest** and **Gradient Boosting**), and automatically deploys the better model on a **Flask** web application.

---

## 📌 Project Overview

Forest fires pose significant risks to human life, ecology, and economies. Early warning systems rely on atmospheric factors and fuel moisture levels. This project:
1. Cleans and consolidates both Algerian study regions (**Bejaia** and **Sidi-Bel Abbes**) from the raw UCI dataset.
2. Formulates a binary classification task: `Classes ∈ {Fire, Not Fire}`.
3. Implements two ensemble algorithms without hyperparameter tuning:
   - `RandomForestClassifier` (Bagging)
   - `GradientBoostingClassifier` (Boosting)
4. Evaluates both models on an identical held-out test set using **Accuracy, Precision, Recall, F1-Score, and ROC-AUC**.
5. Automatically selects the superior model based on test performance (**F1-score primary**, **Recall secondary**, **ROC-AUC tertiary**).
6. Serves predictions through a responsive **Flask** web application featuring a multi-page interface, dual-model probability comparison, and real diagnostic visualizations.

---

## 🗂️ Project Structure

```text
ML PROJECT/
│
├── Algerian_forest_fires_dataset_UPDATE.csv   # Raw UCI dataset (244 records)
│
├── data/
│   ├── cleaned_algerian_fires.csv            # Preprocessed and cleaned dataset
│   ├── dataset_summary.json                  # Class counts, region breakdown, and feature stats
│   ├── train_test_split.pkl                  # Serialized held-out stratified test set
│   └── kmeans_summary.json                   # M4 unsupervised exploratory cluster summary
│
├── models/
│   ├── random_forest_model.pkl               # Serialized RandomForestClassifier artifact
│   ├── gradient_boosting_model.pkl           # Serialized GradientBoostingClassifier artifact
│   └── model_metadata.json                   # Evaluation metrics, selection rationale & winner
│
├── src/
│   ├── __init__.py
│   ├── data_preprocessing.py                 # Dataset cleaning, malformed record fix & encoding
│   ├── train_models.py                       # Stratified splitting & training of RF and GB
│   ├── evaluate_models.py                    # Metric calculation, auto-selection, & plot export
│   └── unsupervised_analysis.py              # M4 K-Means exploratory clustering (not predictor)
│
├── static/
│   ├── css/
│   │   └── style.css                         # Primary stylesheet
│   ├── js/
│   │   └── script.js                         # Presets loader & client validation
│   ├── style.css                             # Root stylesheet import
│   ├── script.js                             # Root script import
│   └── images/
│       ├── model_comparison.png              # Test metrics comparison bar chart
│       ├── feature_importance.png            # MDI feature importance chart
│       ├── confusion_matrices.png            # Dual confusion matrix heatmaps
│       └── kmeans_clusters.png               # M4 K-Means PCA projection plot
│
├── templates/
│   ├── index.html                            # Page 1: Home page & project overview
│   ├── input.html                            # Page 2: Feature input form with test presets
│   ├── result.html                           # Page 3: Dual-model results, disagreement check & graphs
│   └── syllabus.html                         # M1–M6 syllabus mapping & academic concepts
│
├── app.py                                    # Flask web server & prediction endpoints
├── requirements.txt                          # Project Python dependencies
└── README.md                                 # Full documentation & setup guide
```

---

## 📊 Dataset & Preprocessing

The Algerian Forest Fires Dataset comprises weather data collected from June 2012 to September 2012 across two regions in Algeria:
- **Bejaia Region:** 122 observations (coastal, humid northeast)
- **Sidi-Bel Abbes Region:** 122 observations (inland, arid northwest)
- **Total Samples:** 244 valid observations

### Data Cleaning Operations (`src/data_preprocessing.py`):
1. **Multi-Region Extraction:** Automated extraction separating both regions from raw CSV headers and blank separator lines.
2. **Malformed Record Correction:** Fixed the UCI dataset anomaly at line 170 (14/07/2012 in Sidi-Bel Abbes) where `DC` and `ISI` were merged with a space (`14.6 9`) instead of a comma.
3. **Label Normalization:** Resolved trailing whitespace inconsistencies (e.g. `'not fire   '`, `'fire   '`) to clean binary targets (`1: Fire`, `0: Not Fire`).
4. **Generalizable Feature Selection:** Excluded calendar dates (`day`, `month`, `year`) and administrative region identifiers to prevent false temporal correlation and data leakage.
5. **Class Distribution:**
   - **Fire:** 138 instances (56.56%)
   - **Not Fire:** 106 instances (43.44%)

### Core Feature Vector (10 Features):
1. `Temperature`: Noon ambient temperature (°C)
2. `RH`: Relative Humidity (%)
3. `Ws`: Wind speed (km/h)
4. `Rain`: Rainfall over past 24 hours (mm)
5. `FFMC`: Fine Fuel Moisture Code (litter ignition ease)
6. `DMC`: Duff Moisture Code (organic layer moisture)
7. `DC`: Drought Code (deep soil drought index)
8. `ISI`: Initial Spread Index (rate of fire spread)
9. `BUI`: Buildup Index (total fuel availability)
10. `FWI`: Fire Weather Index (overall fire intensity indicator)

---

## 🔬 Model Training & Evaluation Results

Models are trained on 75% of the data (183 samples) with stratified sampling and evaluated on an identical held-out test set (61 samples, 34 Fire, 27 Not Fire).

### Evaluation Comparison Table (Held-Out Test Set):

| Metric | RandomForestClassifier | GradientBoostingClassifier | Selection Impact |
| :--- | :---: | :---: | :--- |
| **Accuracy** | **96.72%** | **96.72%** | Overall correctness |
| **Precision** | **94.44%** | **94.44%** | Low false alarm rate |
| **Recall (Sensitivity)** | **100.00%** | **100.00%** | **Tie-Breaker:** Zero missed fires (FN = 0) |
| **F1-Score** | **97.14%** | **97.14%** | **Primary Metric:** Harmonic mean |
| **ROC-AUC** | **1.0000** | **96.41%** | **Tertiary Discriminator:** Perfect ranking |
| **Confusion Matrix** | `[TN=25, FP=2, FN=0, TP=34]` | `[TN=25, FP=2, FN=0, TP=34]` | Zero False Negatives |

### Automated Selection Decision:
```text
Selected Model: Random Forest
Selection Reason: F1-score (0.9714) and Recall (1.0000) are tied. 
Random Forest achieved superior ROC-AUC discrimination (1.0000 vs 0.9641).
```

---

## 🎓 Syllabus Modules Mapping (M1–M6)

| Module | Title | Implementation Status | Description |
| :---: | :--- | :---: | :--- |
| **M1** | **ML Lifecycle & Problem Formulation** | **Implemented** | Supervised binary classification, end-to-end inference request-response pipeline. |
| **M2** | **Preprocessing & Leakage Prevention** | **Implemented** | Data cleaning, malformed record fixes, feature scaling invariance, stratified split. |
| **M3** | **Ensemble Architectures & Feature Importance** | **Implemented** | Bagging (`RandomForestClassifier`), Boosting (`GradientBoostingClassifier`), MDI feature importance. |
| **M4** | **Unsupervised Learning Concepts** | **Exploratory Only** | `KMeans(k=2)` clustering on weather profiles (strictly exploratory analysis; **not** a third prediction model). |
| **M5** | **Evaluation & Transparent Model Selection** | **Implemented** | Multi-metric evaluation (Accuracy, Precision, Recall, F1, ROC-AUC), automated selection hierarchy. |
| **M6** | **Deployment, Monitoring & Data Drift** | **Implemented & Theory** | Model serialization (`joblib`), Flask serving, REST API, covariate shift & concept drift monitoring theory. |

---

## 💻 Installation & Quickstart Guide

### Step 1: Open VS Code Terminal
Open your project directory in VS Code:
```powershell
cd "c:\Users\DELL\OneDrive\Desktop\ML PROJECT"
```

### Step 2: Install Required Dependencies
```powershell
python -m pip install -r requirements.txt
```

### Step 3: Train and Evaluate Models (Generates Artifacts & Charts)
```powershell
python src/data_preprocessing.py
python src/train_models.py
python src/evaluate_models.py
python src/unsupervised_analysis.py
```

### Step 4: Start the Flask Web Application
```powershell
python app.py
```

### Step 5: Open in Your Web Browser
Open your browser and navigate to:
```text
http://127.0.0.1:5000/
```

---

## 🌐 Website Pages Walkthrough

1. **Page 1: Home Page (`/`)**
   - Displays project overview, Algerian dataset metrics, and Canadian FWI explanation.
   - Highlights the automatically selected model banner: `Selected Model: Random Forest`.
   - Displays the real test performance comparison table and chart previews.
   - Direct action button: **“Predict Fire Risk”**.

2. **Page 2: Input Page (`/predict_form`)**
   - 10 validated input fields for Temperature, RH, Ws, Rain, FFMC, DMC, DC, ISI, BUI, and FWI.
   - **Quick Test Presets:**
     - `High Fire Risk Case`: Hot, dry conditions (Temp: 37°C, RH: 37%, Rain: 0mm).
     - `Low Fire Risk / Safe Case`: Cool, humid conditions (Temp: 25°C, RH: 88%, Rain: 0.2mm).
     - `Borderline Case`: Dataset row 72 where models exhibit fine boundary discrimination.
   - Client and server-side range validation.

3. **Page 3: Prediction Results Page (`/predict`)**
   - Shows both models' individual predictions and fire risk probabilities.
   - Displays consensus or disagreement alerts.
   - Yields the authoritative final decision from the test-evaluation winner: **Selected Model (Random Forest)**.
   - Displays the selected model's test metrics (Accuracy, Precision, Recall, F1, ROC-AUC).
   - Embedded real diagnostic charts:
     - *Figure A:* Test Metrics Comparison Bar Chart
     - *Figure B:* MDI Feature Importance Chart
     - *Figure C:* Confusion Matrix Heatmaps

4. **Page 4: Syllabus & Academic Mapping (`/syllabus`)**
   - In-depth module-by-module breakdown from M1 to M6.
   - Includes the unsupervised K-Means 2D PCA cluster visualization (`kmeans_clusters.png`).

---

## 🔌 Programmatic REST API

The application exposes a prediction API for programmatic integration:

**Endpoint:** `POST /api/predict`  
**Headers:** `Content-Type: application/json`

**Sample Request Body:**
```json
{
  "Temperature": 37.0,
  "RH": 37.0,
  "Ws": 18.0,
  "Rain": 0.0,
  "FFMC": 89.3,
  "DMC": 16.0,
  "DC": 100.7,
  "ISI": 9.7,
  "BUI": 22.9,
  "FWI": 14.6
}
```

**Sample JSON Response:**
```json
{
  "selected_model": "Random Forest",
  "final_prediction": "Fire",
  "final_fire_probability": 1.0,
  "models_agree": true,
  "random_forest": {
    "prediction": "Fire",
    "probability": 1.0
  },
  "gradient_boosting": {
    "prediction": "Fire",
    "probability": 1.0
  }
}
```

---

## 🛡️ License & Academic Integrity
Developed for academic learning and portfolio demonstration under the B.Tech Machine Learning Curriculum. All evaluation metrics are derived directly from empirical held-out testing on the Algerian Forest Fires Dataset without synthetic inflation.
